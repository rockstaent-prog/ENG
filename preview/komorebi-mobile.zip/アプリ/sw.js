// Complete app versions are saved together, so offline starts never mix releases.
const PREFIX = 'komorebi-' + new URL(self.registration.scope).pathname + '-';
const CACHE = PREFIX + '08bfc86bce7c7c09';
const ASSETS = ["assets/index-BSrF4YFp.js","assets/index-uZJBaZ2P.css","avatars/conversation-partner.png","avatars/emma-speaking.png","icons/app-192.png","icons/app-512.png","icons/app.svg","icons/apple-touch-icon.png","index.html","manifest.webmanifest"].map(file => new URL(file, self.registration.scope).href);
const INDEX = new URL('index.html', self.registration.scope).href;
self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  await cache.addAll(ASSETS.map(url => new Request(url, {cache: 'reload'})));
})()));
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const name of await caches.keys()) if (name.startsWith(PREFIX) && name !== CACHE) await caches.delete(name);
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin || !url.href.startsWith(self.registration.scope)) return;
  if (event.request.mode === 'navigate') {
    event.respondWith(caches.open(CACHE).then(async cache => (await cache.match(INDEX)) || fetch(event.request)));
  } else if (ASSETS.includes(url.origin + url.pathname)) {
    event.respondWith(caches.open(CACHE).then(async cache => (await cache.match(url.origin + url.pathname)) || fetch(event.request)));
  }
});
